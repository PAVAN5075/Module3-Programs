package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MyLoginPage {
	
	@FindBy(how=How.ID,id="user")
	private WebElement username;
	
	@FindBy(how=How.ID,id="key")
	private WebElement password;
	
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[3]/td[2]/input")
	private WebElement button;

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void setButton() {
		button.click();
	}
	
}
