package com.cg.project.beans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class IRCTCSearch {
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"origin\"]/span/input")
	private WebElement source;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"destination\"]/span/input")
	private WebElement destination;
	
	@FindBy(how=How.XPATH,xpath="")
	private WebElement doj;
	
	@FindBy(how=How.XPATH,xpath="")
	private WebElement button;
	
	@FindBy(how=How.XPATH,xpath="")
	private WebElement drop1;
	
	@FindBy(how=How.XPATH,xpath="")
	private WebElement drop2;
	
	public String getSource() {
		return source.getAttribute("value");
	}

	public void setSource(String source) {
		this.source.sendKeys(source);
	}

	public String getDestination() {
		return destination.getAttribute("value");
	}

	public void setDestination(String destination) {
		this.destination.sendKeys(destination);
	}

	public String getDoj() {
		return doj.getAttribute("value");
	}

	public void setDoj(String doj) {
		this.doj.sendKeys(doj);
	}


	public void setButton() {
		button.submit();
	}
	

	public WebElement getDrop1() {
		return drop1;
	}

	public void setDrop1(WebElement drop1) {
		this.drop1.findElement(By.xpath("//*[@id=\"origin\"]/span/div/ul/li[3]/span"));
		drop1.click();
	}


	public void setDrop2(WebElement drop2) {
		this.drop2 = drop2;
	}
	
}
