package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GoogleSearch {
	@FindBy(how=How.XPATH,xpath="//*[@id=\"lst-ib\"]")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"tsf\"]/div[2]/div[3]/center/input[1]")
	private WebElement button;

	public String getSearchBox() {
		return searchBox.getAttribute("value");
	}

	public void setSearchBox(String searchBox) {
		this.searchBox.sendKeys("Moto G6 plus");
	}

	public void setButton() {
		button.submit();
	}
}
