package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AmazonSearch {
	
	@FindBy(how=How.ID,id="twotabsearchtextbox")
	private WebElement searchBox;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"nav-search\"]/form/div[2]/div/input")
	private WebElement button;

	public String getSearchBox() {
		return searchBox.getAttribute("value");
	}

	public void setSearchBox(String searchBox) {
		this.searchBox.sendKeys("Moto G6");
	}

	public void setButton() {
		button.submit();
	}
	
	
}
