package com.cg.project.test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//radioButtonTest();
		//checkBoxTest();
		selectTest();
	}


/*private static void checkBoxTest() throws InterruptedException{
	
	
	WebDriver driver=new ChromeDriver();
	  driver.get("D:\\New folder\\new 1.html");
	  WebElement checkbox=driver.findElement(By.id("mayocheckbox"));
	  Thread.sleep(1000);
	  checkbox.click();
	  if(checkbox.isSelected()) {
		  System.out.println("ValueOf Box:-"+checkbox.getAttribute("value"));
	  }
	}*/
	
	private static void selectTest() {
		WebDriver driver=new ChromeDriver();
		driver.get("D:\\New folder\\new 3.html");
		WebElement selectElement=driver.findElement(By.id("select1"));
		Select select=new Select(selectElement);
		select.selectByVisibleText("Yes");
		
	}
	
	/*private static void radioButtonTest() {
		WebDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("D:\\New folder\\new 2.html");
		By elements = By.name("color");
		List<WebElement> radioButtons = driver.findElements(elements);
		WebElement radioBtn=radioButtons.get(2);
		radioBtn.click();
		for(WebElement radioButtton:radioButtons) {
			if(radioButtton.isSelected()) {
				System.out.println(radioButtton.getAttribute("value"));
			}
		}
	}*/
}