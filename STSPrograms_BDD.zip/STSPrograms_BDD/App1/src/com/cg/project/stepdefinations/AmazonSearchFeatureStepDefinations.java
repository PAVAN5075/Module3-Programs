package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.AmazonSearch;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AmazonSearchFeatureStepDefinations {
	
	private WebDriver driver;
	private AmazonSearch searchPage;
	
	@Before(order=1)
	public void setUpStep() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	@Given("^User is on Amazon home page$")
	public void user_is_on_Amazon_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		  driver=new ChromeDriver();
		  driver.get("https://www.amazon.in/");
		  searchPage=new AmazonSearch();
		  PageFactory.initElements(driver,searchPage);
	}

	@When("^User enters Redmi mobiles in search box$")
	public void user_enters_Redmi_mobiles_in_search_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		searchPage.setSearchBox("MotoG6");
		searchPage.setButton();
	}

	@Then("^Redmi mobile models are displayed$")
	public void redmi_mobile_models_are_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualTitle=driver.getTitle();
		  String expectedTitle="Amazon.in: Moto G6 - Smartphones / Smartphones & Basic Mobiles: Electronics";
		  Assert.assertEquals(actualTitle, expectedTitle);
		  driver.close();
	}
	
}
