package com.cg.project.stepdefinations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.IRCTCSearch;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IRCTCSearchStepDefination {
	
	private WebDriver driver;
	private IRCTCSearch searchPage;
	
	@Before(order=1)
	public void setUpStep() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	@Given("^User is on IRCTC home page$")
	public void user_is_on_IRCTC_home_page() throws Throwable {
	    
		 driver=new ChromeDriver();
		  driver.get("https://www.irctc.co.in/nget/train-search");
		  searchPage=new IRCTCSearch();
		  PageFactory.initElements(driver,searchPage);
		
	}

	@When("^User enters Source, Destination and DOJ in the respective SearchBoxes$")
	public void user_enters_Source_Destination_and_DOJ_in_the_respective_SearchBoxes() throws Throwable {
	    
		searchPage.setSource("KSR");
		searchPage.setDrop1();
		
	}

	@Then("^List of Train Services running between given source and destination stations should be displayed$")
	public void list_of_Train_Services_running_between_given_source_and_destination_stations_should_be_displayed() throws Throwable {
	    
		
	}
	
}
