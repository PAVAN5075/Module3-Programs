package com.cg.project.stepdefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class NaukriRegistrationStepDefination {
	
	private WebDriver driver;
	
	@Given("^user is on naukri Signup page$")
	public void user_is_on_naukri_Signup_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.naukri.com/");
	}

	@When("^user enters correct details$")
	public void user_enters_correct_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement searchElement=driver.findElement(By.xpath("//*[@id=\"p0widget\"]/div/div[1]/div/input"));
		   searchElement.click();
		   WebElement searchElement1=driver.findElement(By.xpath("//*[@id=\"flowBifurcation\"]/div[2]/form/div[1]/div/div"));
		   searchElement1.click();
		   WebElement searchElement2=driver.findElement(By.xpath("//*[@id=\"fname\"]"));
		   searchElement2.sendKeys("Pavan");
		   WebElement searchElement3=driver.findElement(By.xpath("//*[@id=\"email\"]"));
		   searchElement3.sendKeys("pavan123@gmail.com");
		   WebElement searchElement4=driver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[3]/div[1]/div/input"));
		   searchElement4.sendKeys("pavan123@gmail.com");
		   WebElement searchElement5=driver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[4]/div[1]/div/input[2]"));
		   searchElement5.sendKeys("1234567890");
		   WebElement searchElement6=driver.findElement(By.name("city"));
		   searchElement6.sendKeys("Chennai");
		   searchElement6.click();
		   WebElement searchElement7=driver.findElement(By.xpath("//*[@id=\"basicDetailForm\"]/div[5]/div/div/div[2]/button"));
		   searchElement7.click();
	}

	@Then("^user successfully creates the naukri account$")
	public void user_successfully_creates_the_naukri_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enters incorrect details$")
	public void user_enters_incorrect_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^'There was a problem creating account' message is displayed$")
	public void there_was_a_problem_creating_account_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	
}
