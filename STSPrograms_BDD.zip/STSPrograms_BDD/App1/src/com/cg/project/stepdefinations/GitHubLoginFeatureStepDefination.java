package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.GitHubLoginPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubLoginFeatureStepDefination {
	
	private WebDriver driver;
	private GitHubLoginPage loginPage;
	
	@Before(order=1)
	public void setUpStep() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	@Given("^User is on Github Signin Page$")
	public void user_is_on_Github_Signin_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=new GitHubLoginPage();
		PageFactory.initElements(driver, loginPage);
	}

	@When("^User enters correct login credentials of 'Github'$")
	public void user_enters_correct_login_credentials_of_Github() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		loginPage.setUsername("PAVAN5075");
		loginPage.setPassword("pavan@1997");
		loginPage.setButton();
	}

	@Then("^Signin page should be updated with 'Github' account page$")
	public void signin_page_should_be_updated_with_Github_account_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle); 
		driver.close();
	}
	
	@When("^User enters incorrect login credentials of 'Github'$")
	public void user_enters_incorrect_login_credentials_of_Github() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement username=driver.findElement(By.id("login_field"));
		 WebElement password=driver.findElement(By.id("password"));
		  username.sendKeys("PAVAN5075");
		  password.sendKeys("pavan@1997");
		  password.submit();
	}

	@Then("^'Incorrect Usename or Password' message should be displayed$")
	public void incorrect_Usename_or_Password_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualName=driver.findElement(By.xpath("//*[@id=\"js-flash-container\"]/div/div")).getText();
		String expectedName="Incorrect username or password.";
		Assert.assertEquals(expectedName, actualName);
		driver.close();
	}
	
}
