package com.cg.project.stepdefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubSignupFeatureStepDefination {
	
	private WebDriver driver;
	
	@Given("^user is on github Signup page$")
	public void user_is_on_github_Signup_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		  driver=new ChromeDriver();
		  driver.get("https://www.amazon.in/");
	}

	@When("^user enters his correct details$")
	public void user_enters_his_correct_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userSearchElement=driver.findElement(By.id("user_login"));
		 userSearchElement.sendKeys("");
		 WebElement emailSearchElement=driver.findElement(By.id("user_email"));
		 emailSearchElement.sendKeys("");
		 WebElement PasswordSearchElement=driver.findElement(By.id("user_password"));
		 PasswordSearchElement.sendKeys("");
		 PasswordSearchElement.submit();
	}

	@Then("^user successfully creates the github account$")
	public void user_successfully_creates_the_github_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enters wrong details$")
	public void user_enters_wrong_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^'There was a problem creating your account' message is displayed$")
	public void there_was_a_problem_creating_your_account_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	
}
