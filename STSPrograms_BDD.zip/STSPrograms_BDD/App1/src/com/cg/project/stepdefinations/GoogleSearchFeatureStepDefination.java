package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.GoogleSearch;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GoogleSearchFeatureStepDefination {
	
	private WebDriver driver;
	private GoogleSearch searchPage;
	
	@Before(order=1)
	public void setUpStep() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	@Given("^User is on Google Home Page$")
	public void user_is_on_Google_Home_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		searchPage=new GoogleSearch();
		PageFactory.initElements(driver,searchPage);
	}

	@When("^User searches from  'Agile Methodology'$")
	public void user_searches_from_Agile_Methodology() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  searchPage.setSearchBox("Moto G6plus");
	  searchPage.setButton();
	}

	@Then("^All page links should be displayed with 'Agile Methodology' information$")
	public void all_page_links_should_be_displayed_with_Agile_Methodology_information() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualTitle=driver.getTitle();
		String expectedTitle="Moto G6 plus - Google Search";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	

}
