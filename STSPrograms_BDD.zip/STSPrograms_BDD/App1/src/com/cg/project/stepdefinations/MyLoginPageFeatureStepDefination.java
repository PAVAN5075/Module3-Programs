package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.project.beans.MyLoginPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyLoginPageFeatureStepDefination {
	
	private WebDriver driver;
	private MyLoginPage loginPage;
	
	@Before(order=1)
	public void setUpStep() {
		System.setProperty("webdriver.chrome.driver", "D:\\Software\\chromedriver.exe");
	}
	
	@Given("^User is on Login Page$")
	public void user_is_on_Login_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("D:\\New folder\\new 1.html");
		loginPage=new MyLoginPage();
		PageFactory.initElements(driver, loginPage);
		
	}

	@When("^User enters correct login credentials$")
	public void user_enters_correct_login_credentials() throws Throwable {
		loginPage.setUsername("admin");
		loginPage.setPassword("123");
		loginPage.setButton();
	}

	@Then("^'login successful' message should be displayed$")
	public void login_successful_message_should_be_displayed() throws Throwable {
		
		String actualText=driver.switchTo().alert().getText();
		//String actualText=driver.findElement(By.xpath("/html/body")).getText();
		String expectedText="login successful.";
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}

	@When("^User enters incorrect login credentials$")
	public void user_enters_incorrect_login_credentials() throws Throwable {
		loginPage.setUsername("admijln");
		loginPage.setPassword("13rhjygj2");
		loginPage.setButton();
		
	}

	@Then("^'validation failed' message should be displayed$")
	public void validation_failed_message_should_be_displayed() throws Throwable {
	   
		String actualText=driver.switchTo().alert().getText();
		//String actualText=driver.findElement(By.xpath("/html/body")).getText();
		String expectedText="validation failed.";
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}
	
	@When("^User doesnot enter the username and password$")
	public void user_doesnot_enter_the_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		loginPage.setUsername("");
		loginPage.setPassword("");
		loginPage.setButton();
	}

	@Then("^'Enter Username and Password' message should be displayed$")
	public void enter_Username_and_Password_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualText=driver.switchTo().alert().getText();
		String expectedText="Enter Username and Password.";
		Assert.assertEquals(expectedText, actualText);
		
	}

	@When("^User doesnot enter the username$")
	public void user_doesnot_enter_the_username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		loginPage.setUsername("");
		loginPage.setPassword("123");
		loginPage.setButton();
	}

	@Then("^'Enter Username' message should be displayed$")
	public void enter_Username_message_should_be_displayed() throws Throwable {
		String actualText=driver.switchTo().alert().getText();
		String expectedText="Enter the username.";
		Assert.assertEquals(expectedText, actualText);
	}

	@When("^User doesnot enter the password$")
	public void user_doesnot_enter_the_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		loginPage.setUsername("admin");
		loginPage.setPassword("");
		loginPage.setButton();
	}

	@Then("^'Enter Password' message should be displayed$")
	public void enter_Password_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String actualText=driver.switchTo().alert().getText();
		String expectedText="Enter the password.";
		Assert.assertEquals(expectedText, actualText);
		driver.close();
	}
}
