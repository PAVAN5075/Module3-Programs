package com.cg.project.stepdefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RedBusSearchStepDefination {
	
	private WebDriver driver;
	
	@Given("^User is on RedBus home page$")
	public void user_is_on_RedBus_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		  driver=new ChromeDriver();
		  driver.get("https://www.redbus.in/");
	}

	@When("^User enters Source, Destination and DOJ in SearchBox$")
	public void user_enters_Source_Destination_and_DOJ_in_SearchBox() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement searchElement4=driver.findElement(By.xpath("//*[@id=\"src\"]"));
		   searchElement4.sendKeys("bangalore");
		   Select select=new Select(searchElement4);
			select.selectByVisibleText("Bangalore");
			searchElement4.click();
		   /*WebElement searchElement5=driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[1]/div/ul/li[1]"));
		   searchElement5.click();*/
		   WebElement searchElement6=driver.findElement(By.xpath("//*[@id=\"dest\"]"));
		   searchElement6.sendKeys("Khammam");
		   Select select1=new Select(searchElement6);
			select.selectByVisibleText("Khammam");
			searchElement4.click();
		   /*WebElement searchElement7=driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[2]/div/ul/li[1]"));
		   searchElement7.click();*/
		   WebElement searchElement8=driver.findElement(By.xpath("//*[@id=\"search\"]/div/div[3]/span"));
		   searchElement8.click();
		   WebElement searchElement9=driver.findElement(By.xpath("//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[7]/td[3]"));
		   searchElement9.click();
		   WebElement searchElement0=driver.findElement(By.xpath("//*[@id=\"search_btn\"]"));
		   searchElement0.click();
		   
	}

	@Then("^List of Bus Services are displayed$")
	public void list_of_Bus_Services_are_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	
}
