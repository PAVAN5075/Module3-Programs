package com.cg.app.stepdefinations;
import java.util.List;

import org.junit.Assert;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.cg.app.bean.Product;

import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OnlineShoppingTestBDDStepDefinations {
	
	private TestRestTemplate restTemplate;
	private ResponseEntity<String> responseEntity;
	private ResponseEntity<Product> responseEntityProduct;
	private ResponseEntity<List> responseEntityViewAllProducts;
	private ResponseEntity<Product> responseEntityByProductId;
	@Before
	public void setUpTestEnv() {
	restTemplate=new TestRestTemplate();
	}

	
	@When("^User give call to '/sayHello' Service$")
	public void user_give_call_to_sayHello_Service() throws Throwable {
		responseEntity= restTemplate.getForEntity("http://localhost:7878/sayHello", String.class);
		
	}

	@Then("^user should receive service status 'OK' And reponse message 'Hello World From RestFulWebService'$")
	public void user_should_receive_service_status_OK_And_reponse_message_Hello_World_From_RestFulWebService() throws Throwable {
		Assert.assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
		Assert.assertEquals("HEllo World from Restful Web Services", responseEntity.getBody());

	}

	@When("^User submit valid details$")
	public void user_submit_valid_details() throws Throwable {
		Product product=getProduct();
	    
	    MultiValueMap<String, Object> map=new LinkedMultiValueMap<>();
	    map.add("id", product.getId());
	    map.add("name", product.getName());
	    map.add("description",product.getDescription());
	    map.add("price",Double.toString(product.getPrice()));
	    map.add("date", product.getDate());
	    
	    HttpHeaders headers=new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
	    HttpEntity<MultiValueMap<String, Object>> httpEntity=new HttpEntity<>(map,headers);
	    
	    responseEntityProduct=restTemplate.postForEntity("http://localhost:7878/acceptProductDetails", httpEntity, Product.class);
	    

	}
	private Product getProduct() {
		// TODO Auto-generated method stub
		return new Product("1001", "Oneplus", "6", 39999, "08-08-2018");
	}

	@Then("^Product details should be added successfully$")
	public void product_details_should_be_added_successfully() throws Throwable {
		Product expected=getProduct();
		Product actual=responseEntityProduct.getBody();
		Assert.assertEquals(expected, actual);

		
	}
	
	@When("^User gives call to '/viewAllProducts'$")
	public void user_gives_call_to_viewAllProducts() throws Throwable {
		responseEntityViewAllProducts=restTemplate.getForEntity("http://localhost:7878/viewAllProducts",List.class);

	}

	@Then("^all product details should be displayed$")
	public void all_product_details_should_be_displayed() throws Throwable {
		Assert.assertEquals(HttpStatus.OK,responseEntityViewAllProducts.getStatusCode());
	}

	@When("^User gives a call to '/viewById'$")
	public void user_gives_a_call_to_viewById() throws Throwable {
		responseEntityByProductId=restTemplate.getForEntity("http://localhost:7878/viewById/?id=1001",Product.class);

	}

	@Then("^the product details of that Id should be displayed$")
	public void the_product_details_of_that_Id_should_be_displayed() throws Throwable {
		Assert.assertEquals(HttpStatus.OK,responseEntityByProductId.getStatusCode());

	}
}
