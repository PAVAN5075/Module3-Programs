package com.cg.registration.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class EducationalDetailsRegistrationPage {
	
	@FindBy(name="graduation")
	public List<WebElement> graduation;
	
	@FindBy(how=How.ID, id="txtPercentage")
	private WebElement percentage;
	
	@FindBy(how=How.ID, id="txtPassYear")
	private WebElement passingYear;
	
	@FindBy(how=How.ID, id="txtProjectName")
	private WebElement projectName;
	
	@FindBy(how=How.ID, id="txtOtherTechs")
	private WebElement otherTechnologies;
	
	@FindBy(how=How.XPATH, xpath="//*[@id=\"btnRegister\"]")
	public WebElement registerMe;

	public void setGraduation(String graduation) {
		Select select = new Select(this.graduation.get(0));
	    select.selectByVisibleText(graduation);
	}


	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return this.passingYear.getAttribute("passingYear");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return this.projectName.getAttribute("projectName");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getOtherTechnologies() {
		return this.otherTechnologies.getAttribute("otherTechnologies");
	}

	public void setOtherTechnologies(String otherTechnologies) {
		this.otherTechnologies.sendKeys(otherTechnologies);
	}
	
	public void clickRegister() {
		 registerMe.click();
	}
}
