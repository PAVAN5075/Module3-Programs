package com.cg.registration.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.registration.bean.EducationalDetailsRegistrationPage;
import com.cg.registration.bean.PersonalDetailsRegistrationPage;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinitions {
	
	private WebDriver driver;
	private PersonalDetailsRegistrationPage personal;
	private EducationalDetailsRegistrationPage educational;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe" );
	}
	
	@Given("^user is on personaldetails registration page$")
	public void user_is_on_personaldetails_registration_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("C:\\Users\\pkomarra\\Downloads\\WebPages_Set 3\\PersonalDetails.html");
		personal = PageFactory.initElements(driver, PersonalDetailsRegistrationPage.class);
		educational = PageFactory.initElements(driver, EducationalDetailsRegistrationPage.class);
	}

	@Then("^personaldetails registration page should load with tile 'Personal Details'$")
	public void personaldetails_registration_page_should_load_with_tile_Personal_Details() throws Throwable {
		String expectedTitle="Personal Details";
		String actualTitle=driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user clicks on next without entering First Name$")
	public void user_clicks_on_next_without_entering_First_Name() throws Throwable {
		personal.setFirstname("");
		personal.clickNext();
	}

	@Then("^'Please fill the First Name' message should be displayed$")
	public void please_fill_the_First_Name_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(4000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without entering Last Name$")
	public void user_clicks_on_next_without_entering_Last_Name() throws Throwable {
		personal.setFirstname("Pavan");
		personal.clickNext();
	}

	@Then("^'Please fill the Last Name' message should be displayed$")
	public void please_fill_the_Last_Name_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without entering Email$")
	public void user_clicks_on_next_without_entering_Email() throws Throwable {
		personal.setLastname("Komarraju");
		personal.clickNext();
	}

	@Then("^'Please fill the Email' message should displayed$")
	public void please_fill_the_Email_message_should_displayed() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without entering Contact no\\.$")
	public void user_clicks_on_next_without_entering_Contact_no() throws Throwable {
		personal.setEmail("pavan@gmail.com");
		personal.clickNext();
	}

	@Then("^'Please fill the Contact No\\.' message should be displayed$")
	public void please_fill_the_Contact_No_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please fill the Contact No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next withot entering valid Contact no\\.$")
	public void user_clicks_on_next_withot_entering_valid_Contact_no() throws Throwable {
		personal.setContactNo("90000");
		personal.clickNext();
	}

	@Then("^'Please enter valid Contact no\\.' message should be displayed$")
	public void please_enter_valid_Contact_no_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without entering address lineA$")
	public void user_clicks_on_next_without_entering_address_lineA() throws Throwable {
		personal.setContactNo("12345");
	    personal.clickNext();
	}
	
	@Then("^'Please fill the address line(\\d+)' message should display$")
	public void please_fill_the_address_line_message_should_display(int arg1) throws Throwable {
		String expectedMessage="Please fill the address line 1";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}
	
	@When("^user clicks on next without entering address lineB$")
	public void user_clicks_on_next_without_entering_address_lineB() throws Throwable {
		personal.setAddressLine1("ATP");
		personal.clickNext();
	}

	@Then("^'Please fill the address line(\\d+)' message should displayed$")
	public void please_fill_the_address_line_message_should_displayed(int arg1) throws Throwable {
		String expectedMessage="Please fill the address line 2";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without selecting city$")
	public void user_clicks_on_next_without_selecting_city() throws Throwable {
		personal.setAddressLine2("Whitefield");
		personal.clickNext();
	}

	@Then("^'Please select city' message should be displayed$")
	public void please_select_city_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(4000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next without selecting State$")
	public void user_clicks_on_next_without_selecting_State() throws Throwable {
		personal.setCity("Pune");
		personal.clickNext();
	}

	@Then("^'Please select state' message should be displayed$")
	public void please_select_state_message_should_be_displayed() throws Throwable {
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on next by entering all valid details$")
	public void user_clicks_on_next_by_entering_all_valid_details() throws Throwable {
		personal.setState("Maharashtra");
		personal.clickNext();
	}

	@Then("^'Personal details are validated and accepted successfully\\.' message should be displayed$")
	public void personal_details_are_validated_and_accepted_successfully_message_should_be_displayed() throws Throwable {
		String expectedMessage="Personal details are validated and accepted successfully.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		
	}

	@Then("^navigates to the Educational Details Page$")
	public void navigates_to_the_Educational_Details_Page() throws Throwable {
		driver.switchTo().alert().dismiss();
	}
	
	@When("^user is on educationaldetails registration page$")
	public void user_is_on_educationaldetails_registration_page() throws Throwable {
	    
	}

	@Then("^Educational Details registration page should loaded with tile 'Educational Details'$")
	public void educational_Details_registration_page_should_loaded_with_tile_Educational_Details() throws Throwable {
		String expectedTitle="Educational Details";
		String actualTitle=driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^user clicks on make Register Me without selecting Graduation$")
	public void user_clicks_on_make_Register_Me_without_selecting_Graduation() throws Throwable {
	    educational.clickRegister();
	}

	@Then("^'Please Select Graduation' message should display$")
	public void please_Select_Graduation_message_should_display() throws Throwable {
		String expectedMessage="Please Select Graduation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on make Register Me without entering Percentage$")
	public void user_clicks_on_make_Register_Me_without_entering_Percentage() throws Throwable {
		educational.setGraduation("BTech");
		educational.clickRegister();
	}

	@Then("^'Please fill Percentage detail' message should display$")
	public void please_fill_Percentage_detail_message_should_display() throws Throwable {
		String expectedMessage="Please fill Percentage detail";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on make Register Me without entering Passing Year$")
	public void user_clicks_on_make_Register_Me_without_entering_Passing_Year() throws Throwable {
	    educational.setPercentage("88");
	    educational.clickRegister();
	}

	@Then("^'Please fill Passing Year' message should display$")
	public void please_fill_Passing_Year_message_should_display() throws Throwable {
		String expectedMessage="Please fill Passing Year";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on make Register Me without entering Project Name$")
	public void user_clicks_on_make_Register_Me_without_entering_Project_Name() throws Throwable {
	    educational.setPassingYear("2018");
	    educational.clickRegister();
	}

	@Then("^'Please fill Project Name' message should display$")
	public void please_fill_Project_Name_message_should_display() throws Throwable {
		String expectedMessage="Please fill Project Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on make Register Me without selecting Technologies$")
	public void user_clicks_on_make_Register_Me_without_selecting_Technologies() throws Throwable {
	   educational.setProjectName("ABC");
	   educational.clickRegister();
	}

	@Then("^'Please select the Technologies used' message should display$")
	public void please_select_the_Technologies_used_message_should_display() throws Throwable {
		String expectedMessage="Please Select Technologies Used";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on make Register Me by selecting others in Technologies and not entering anything in text box$")
	public void user_clicks_on_make_Register_Me_by_selecting_others_in_Technologies_and_not_entering_anything_in_text_box() throws Throwable {
		WebElement checkbox=driver.findElement(By.xpath("//*[@id=\"cbTechnologies\"]"));
		checkbox.click();
		educational.clickRegister();
	}

	/*@Then("^'Please fill other Technologies used' message should display$")
	public void please_fill_other_Technologies_used_message_should_display() throws Throwable {
		String expectedMessage="Please fill other Technologies Used";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();
	}

	@When("^user clicks on Register Me with valid details$")
	public void user_clicks_on_Register_Me_with_valid_details() throws Throwable {
	    educational.setOtherTechnologies("Spring Boot");
	    educational.clickRegister();
	}*/

	@Then("^'Your registration Has successfully done plz check your registered email for account activation link!!!' message should display$")
	public void your_registration_Has_successfully_done_plz_check_your_registered_email_for_account_activation_link_message_should_display() throws Throwable {
		String expectedMessage="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(4000);
		driver.switchTo().alert().dismiss();
		driver.close();
	}
}
