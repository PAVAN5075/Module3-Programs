package com.cg.service;

import java.util.List;
import com.cg.bean.Product;
import com.cg.exception.ProductException;

public interface IProductService {

	Product createProduct(Product product) throws ProductException;
	List<Product> viewProduct() throws ProductException;
	Product findProductById(String id)throws ProductException;
}
