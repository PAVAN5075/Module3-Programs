package com.cg.controller;

import java.util.List;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;
import com.cg.service.ProductServiceImpl;


@RestController
public class ProductManagementSystemController {
	
	@Autowired
	private IProductService service;
	
	@RequestMapping(value="/createProduct",method=RequestMethod.POST)
	public Product createProduct(@RequestBody Product product) throws ProductException {
		
		try {
			Product product2=service.createProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			throw new ProductException(e.getMessage());
		}
		return product;
		
	}
	
	@RequestMapping(value="/viewProduct",method=RequestMethod.GET)
	public List<Product> viewProduct() {
		List<Product> products=null;
		try {
			products=service.viewProduct();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return products;
		
	}
	
	@RequestMapping(value="/findProductById",method=RequestMethod.GET)
	public Product findProductById(String id) {
		Product product=null;
		try {
			product=service.findProductById(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return product;
		
		
	}
	
	@RequestMapping(method=RequestMethod.GET, value= {"/sayHello"}, produces= {"application/text"})
	public ResponseEntity<String>getHelloMessage(){
		return new ResponseEntity<String>("HEllo World from Restful Web Services",HttpStatus.OK);
	}
	
	@RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<Product> acceptProductDetails(@ModelAttribute Product product) throws ProductException{
	//onlineShopServices.acceptProductDetails(product);
	service.createProduct(product);
	return new ResponseEntity<>(product,HttpStatus.OK);
	}

	@RequestMapping(value="/viewAllProducts",method=RequestMethod.GET,produces= {"application/JSON"})
	public ResponseEntity<List> viewAllProducts() throws ProductException{
	return new ResponseEntity<>(service.viewProduct(),HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/viewById",method=RequestMethod.GET,produces= {"application/JSON"})
	public ResponseEntity<Product> viewById(@PathParam(value="id") String id) throws ProductException{
		
		return new ResponseEntity<>(service.findProductById(id),HttpStatus.OK);
		}
	}
	

