package com.cg.service;

import java.util.List;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.repo.ProductRepo;

/*Class name: ProductManagementSystemController

5 Methods : createProduct, updateProduct, deleteProduct, viewProduct, findProductById

Author: Pavan Sudhakar Komarraju*/

@Service

public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private ProductRepo repo;
	

	@Override
	public Product createProduct(Product product) throws ProductException {
		 {
		repo.save(product);
		}
		return product;
	}

	
	@Override
	public List<Product> viewProduct() throws ProductException {
		// TODO Auto-generated method stub
		
		return repo.findAll();
	}

	@Override
	public Product findProductById(String id) throws ProductException {
		// TODO Auto-generated method stub
		
		return repo.getOne(id);
	}
	



}
